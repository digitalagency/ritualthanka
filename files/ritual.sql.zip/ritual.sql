-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 10, 2018 at 06:24 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ritual`
--

-- --------------------------------------------------------

--
-- Table structure for table `artists`
--

CREATE TABLE `artists` (
  `id` int(10) UNSIGNED NOT NULL,
  `fullname` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` longtext COLLATE utf8mb4_unicode_ci,
  `dob` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `buyers_allocations`
--

CREATE TABLE `buyers_allocations` (
  `id` int(10) UNSIGNED NOT NULL,
  `userid` int(11) NOT NULL,
  `allocation` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `buyers_allocations`
--

INSERT INTO `buyers_allocations` (`id`, `userid`, `allocation`, `created_at`, `updated_at`) VALUES
(1, 3, '20', '2018-05-29 00:33:17', '2018-05-29 00:33:17'),
(2, 5, '30', '2018-05-29 00:37:01', '2018-05-29 00:37:31');

-- --------------------------------------------------------

--
-- Table structure for table `cat_relations`
--

CREATE TABLE `cat_relations` (
  `id` int(10) UNSIGNED NOT NULL,
  `postid` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cat_relations`
--

INSERT INTO `cat_relations` (`id`, `postid`, `catid`, `created_at`, `updated_at`) VALUES
(5, 13, 6, '2018-05-22 22:57:30', '2018-05-22 22:57:30'),
(28, 21, 14, '2018-06-28 16:23:46', '2018-06-28 16:23:46'),
(29, 22, 16, '2018-06-28 16:24:00', '2018-06-28 16:24:00'),
(32, 27, 14, '2018-06-29 13:12:20', '2018-06-29 13:12:20'),
(33, 26, 14, '2018-06-29 13:12:39', '2018-06-29 13:12:39'),
(36, 24, 14, '2018-06-29 13:13:53', '2018-06-29 13:13:53'),
(37, 23, 14, '2018-06-29 13:14:26', '2018-06-29 13:14:26'),
(38, 28, 14, '2018-06-29 13:17:37', '2018-06-29 13:17:37'),
(39, 29, 14, '2018-06-29 13:33:55', '2018-06-29 13:33:55'),
(40, 30, 14, '2018-06-29 13:37:02', '2018-06-29 13:37:02'),
(42, 32, 14, '2018-06-29 13:40:04', '2018-06-29 13:40:04'),
(43, 31, 14, '2018-06-29 13:41:35', '2018-06-29 13:41:35'),
(44, 12, 13, '2018-07-02 12:17:04', '2018-07-02 12:17:04'),
(47, 25, 16, '2018-07-04 10:34:32', '2018-07-04 10:34:32'),
(51, 33, 16, '2018-07-06 13:31:05', '2018-07-06 13:31:05'),
(52, 34, 15, '2018-07-06 13:57:14', '2018-07-06 13:57:14'),
(53, 18, 10, '2018-07-15 14:48:24', '2018-07-15 14:48:24');

-- --------------------------------------------------------

--
-- Table structure for table `exchange_rates`
--

CREATE TABLE `exchange_rates` (
  `id` int(10) UNSIGNED NOT NULL,
  `country_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `exchange_rates`
--

INSERT INTO `exchange_rates` (`id`, `country_code`, `country_name`, `rate`, `created_at`, `updated_at`) VALUES
(1, 'AF', 'Afghanistan', '200', NULL, '2018-05-28 23:44:25'),
(2, 'AL', 'Albania', '105', NULL, '0000-00-00 00:00:00'),
(3, 'DZ', 'Algeria', NULL, NULL, NULL),
(4, 'DS', 'American Samoa', NULL, NULL, NULL),
(5, 'AD', 'Andorra', NULL, NULL, NULL),
(6, 'AO', 'Angola', NULL, NULL, NULL),
(7, 'AI', 'Anguilla', NULL, NULL, NULL),
(8, 'AQ', 'Antarctica', NULL, NULL, NULL),
(9, 'AG', 'Antigua and Barbuda', NULL, NULL, NULL),
(10, 'AR', 'Argentina', NULL, NULL, NULL),
(11, 'AM', 'Armenia', NULL, NULL, NULL),
(12, 'AW', 'Aruba', NULL, NULL, NULL),
(13, 'AU', 'Australia', NULL, NULL, NULL),
(14, 'AT', 'Austria', NULL, NULL, NULL),
(15, 'AZ', 'Azerbaijan', NULL, NULL, NULL),
(16, 'BS', 'Bahamas', NULL, NULL, NULL),
(17, 'BH', 'Bahrain', NULL, NULL, NULL),
(18, 'BD', 'Bangladesh', NULL, NULL, NULL),
(19, 'BB', 'Barbados', NULL, NULL, NULL),
(20, 'BY', 'Belarus', NULL, NULL, NULL),
(21, 'BE', 'Belgium', NULL, NULL, NULL),
(22, 'BZ', 'Belize', NULL, NULL, NULL),
(23, 'BJ', 'Benin', NULL, NULL, NULL),
(24, 'BM', 'Bermuda', NULL, NULL, NULL),
(25, 'BT', 'Bhutan', NULL, NULL, NULL),
(26, 'BO', 'Bolivia', NULL, NULL, NULL),
(27, 'BA', 'Bosnia and Herzegovina', NULL, NULL, NULL),
(28, 'BW', 'Botswana', NULL, NULL, NULL),
(29, 'BV', 'Bouvet Island', NULL, NULL, NULL),
(30, 'BR', 'Brazil', NULL, NULL, NULL),
(31, 'IO', 'British Indian Ocean Territory', NULL, NULL, NULL),
(32, 'BN', 'Brunei Darussalam', NULL, NULL, NULL),
(33, 'BG', 'Bulgaria', NULL, NULL, NULL),
(34, 'BF', 'Burkina Faso', NULL, NULL, NULL),
(35, 'BI', 'Burundi', NULL, NULL, NULL),
(36, 'KH', 'Cambodia', NULL, NULL, NULL),
(37, 'CM', 'Cameroon', NULL, NULL, NULL),
(38, 'CA', 'Canada', NULL, NULL, NULL),
(39, 'CV', 'Cape Verde', NULL, NULL, NULL),
(40, 'KY', 'Cayman Islands', NULL, NULL, NULL),
(41, 'CF', 'Central African Republic', NULL, NULL, NULL),
(42, 'TD', 'Chad', NULL, NULL, NULL),
(43, 'CL', 'Chile', NULL, NULL, NULL),
(44, 'CN', 'China', NULL, NULL, NULL),
(45, 'CX', 'Christmas Island', NULL, NULL, NULL),
(46, 'CC', 'Cocos (Keeling) Islands', NULL, NULL, NULL),
(47, 'CO', 'Colombia', NULL, NULL, NULL),
(48, 'KM', 'Comoros', NULL, NULL, NULL),
(49, 'CG', 'Congo', NULL, NULL, NULL),
(50, 'CK', 'Cook Islands', NULL, NULL, NULL),
(51, 'CR', 'Costa Rica', NULL, NULL, NULL),
(52, 'HR', 'Croatia (Hrvatska)', NULL, NULL, NULL),
(53, 'CU', 'Cuba', NULL, NULL, NULL),
(54, 'CY', 'Cyprus', NULL, NULL, NULL),
(55, 'CZ', 'Czech Republic', NULL, NULL, NULL),
(56, 'DK', 'Denmark', NULL, NULL, NULL),
(57, 'DJ', 'Djibouti', NULL, NULL, NULL),
(58, 'DM', 'Dominica', NULL, NULL, NULL),
(59, 'DO', 'Dominican Republic', NULL, NULL, NULL),
(60, 'TP', 'East Timor', NULL, NULL, NULL),
(61, 'EC', 'Ecuador', NULL, NULL, NULL),
(62, 'EG', 'Egypt', NULL, NULL, NULL),
(63, 'SV', 'El Salvador', NULL, NULL, NULL),
(64, 'GQ', 'Equatorial Guinea', NULL, NULL, NULL),
(65, 'ER', 'Eritrea', NULL, NULL, NULL),
(66, 'EE', 'Estonia', NULL, NULL, NULL),
(67, 'ET', 'Ethiopia', NULL, NULL, NULL),
(68, 'FK', 'Falkland Islands (Malvinas)', NULL, NULL, NULL),
(69, 'FO', 'Faroe Islands', NULL, NULL, NULL),
(70, 'FJ', 'Fiji', NULL, NULL, NULL),
(71, 'FI', 'Finland', NULL, NULL, NULL),
(72, 'FR', 'France', NULL, NULL, NULL),
(73, 'FX', 'France, Metropolitan', NULL, NULL, NULL),
(74, 'GF', 'French Guiana', NULL, NULL, NULL),
(75, 'PF', 'French Polynesia', NULL, NULL, NULL),
(76, 'TF', 'French Southern Territories', NULL, NULL, NULL),
(77, 'GA', 'Gabon', NULL, NULL, NULL),
(78, 'GM', 'Gambia', NULL, NULL, NULL),
(79, 'GE', 'Georgia', NULL, NULL, NULL),
(80, 'DE', 'Germany', NULL, NULL, NULL),
(81, 'GH', 'Ghana', NULL, NULL, NULL),
(82, 'GI', 'Gibraltar', NULL, NULL, NULL),
(83, 'GK', 'Guernsey', NULL, NULL, NULL),
(84, 'GR', 'Greece', NULL, NULL, NULL),
(85, 'GL', 'Greenland', NULL, NULL, NULL),
(86, 'GD', 'Grenada', NULL, NULL, NULL),
(87, 'GP', 'Guadeloupe', NULL, NULL, NULL),
(88, 'GU', 'Guam', NULL, NULL, NULL),
(89, 'GT', 'Guatemala', NULL, NULL, NULL),
(90, 'GN', 'Guinea', NULL, NULL, NULL),
(91, 'GW', 'Guinea-Bissau', NULL, NULL, NULL),
(92, 'GY', 'Guyana', NULL, NULL, NULL),
(93, 'HT', 'Haiti', NULL, NULL, NULL),
(94, 'HM', 'Heard and Mc Donald Islands', NULL, NULL, NULL),
(95, 'HN', 'Honduras', NULL, NULL, NULL),
(96, 'HK', 'Hong Kong', NULL, NULL, NULL),
(97, 'HU', 'Hungary', NULL, NULL, NULL),
(98, 'IS', 'Iceland', NULL, NULL, NULL),
(99, 'IN', 'India', NULL, NULL, NULL),
(100, 'IM', 'Isle of Man', NULL, NULL, NULL),
(101, 'ID', 'Indonesia', NULL, NULL, NULL),
(102, 'IR', 'Iran (Islamic Republic of)', NULL, NULL, NULL),
(103, 'IQ', 'Iraq', NULL, NULL, NULL),
(104, 'IE', 'Ireland', NULL, NULL, NULL),
(105, 'IL', 'Israel', NULL, NULL, NULL),
(106, 'IT', 'Italy', NULL, NULL, NULL),
(107, 'CI', 'Ivory Coast', NULL, NULL, NULL),
(108, 'JE', 'Jersey', NULL, NULL, NULL),
(109, 'JM', 'Jamaica', NULL, NULL, NULL),
(110, 'JP', 'Japan', NULL, NULL, NULL),
(111, 'JO', 'Jordan', NULL, NULL, NULL),
(112, 'KZ', 'Kazakhstan', NULL, NULL, NULL),
(113, 'KE', 'Kenya', NULL, NULL, NULL),
(114, 'KI', 'Kiribati', NULL, NULL, NULL),
(115, 'KP', 'Korea, Democratic People\'s Republic of', NULL, NULL, NULL),
(116, 'KR', 'Korea, Republic of', NULL, NULL, NULL),
(117, 'XK', 'Kosovo', NULL, NULL, NULL),
(118, 'KW', 'Kuwait', NULL, NULL, NULL),
(119, 'KG', 'Kyrgyzstan', NULL, NULL, NULL),
(120, 'LA', 'Lao People\'s Democratic Republic', NULL, NULL, NULL),
(121, 'LV', 'Latvia', NULL, NULL, NULL),
(122, 'LB', 'Lebanon', NULL, NULL, NULL),
(123, 'LS', 'Lesotho', NULL, NULL, NULL),
(124, 'LR', 'Liberia', NULL, NULL, NULL),
(125, 'LY', 'Libyan Arab Jamahiriya', NULL, NULL, NULL),
(126, 'LI', 'Liechtenstein', NULL, NULL, NULL),
(127, 'LT', 'Lithuania', NULL, NULL, NULL),
(128, 'LU', 'Luxembourg', NULL, NULL, NULL),
(129, 'MO', 'Macau', NULL, NULL, NULL),
(130, 'MK', 'Macedonia', NULL, NULL, NULL),
(131, 'MG', 'Madagascar', NULL, NULL, NULL),
(132, 'MW', 'Malawi', NULL, NULL, NULL),
(133, 'MY', 'Malaysia', NULL, NULL, NULL),
(134, 'MV', 'Maldives', NULL, NULL, NULL),
(135, 'ML', 'Mali', NULL, NULL, NULL),
(136, 'MT', 'Malta', NULL, NULL, NULL),
(137, 'MH', 'Marshall Islands', NULL, NULL, NULL),
(138, 'MQ', 'Martinique', NULL, NULL, NULL),
(139, 'MR', 'Mauritania', NULL, NULL, NULL),
(140, 'MU', 'Mauritius', NULL, NULL, NULL),
(141, 'TY', 'Mayotte', NULL, NULL, NULL),
(142, 'MX', 'Mexico', NULL, NULL, NULL),
(143, 'FM', 'Micronesia, Federated States of', NULL, NULL, NULL),
(144, 'MD', 'Moldova, Republic of', NULL, NULL, NULL),
(145, 'MC', 'Monaco', NULL, NULL, NULL),
(146, 'MN', 'Mongolia', NULL, NULL, NULL),
(147, 'ME', 'Montenegro', NULL, NULL, NULL),
(148, 'MS', 'Montserrat', NULL, NULL, NULL),
(149, 'MA', 'Morocco', NULL, NULL, NULL),
(150, 'MZ', 'Mozambique', NULL, NULL, NULL),
(151, 'MM', 'Myanmar', NULL, NULL, NULL),
(152, 'NA', 'Namibia', NULL, NULL, NULL),
(153, 'NR', 'Nauru', NULL, NULL, NULL),
(154, 'NP', 'Nepal', NULL, NULL, NULL),
(155, 'NL', 'Netherlands', NULL, NULL, NULL),
(156, 'AN', 'Netherlands Antilles', NULL, NULL, NULL),
(157, 'NC', 'New Caledonia', NULL, NULL, NULL),
(158, 'NZ', 'New Zealand', NULL, NULL, NULL),
(159, 'NI', 'Nicaragua', NULL, NULL, NULL),
(160, 'NE', 'Niger', NULL, NULL, NULL),
(161, 'NG', 'Nigeria', NULL, NULL, NULL),
(162, 'NU', 'Niue', NULL, NULL, NULL),
(163, 'NF', 'Norfolk Island', NULL, NULL, NULL),
(164, 'MP', 'Northern Mariana Islands', NULL, NULL, NULL),
(165, 'NO', 'Norway', NULL, NULL, NULL),
(166, 'OM', 'Oman', NULL, NULL, NULL),
(167, 'PK', 'Pakistan', NULL, NULL, NULL),
(168, 'PW', 'Palau', NULL, NULL, NULL),
(169, 'PS', 'Palestine', NULL, NULL, NULL),
(170, 'PA', 'Panama', NULL, NULL, NULL),
(171, 'PG', 'Papua New Guinea', NULL, NULL, NULL),
(172, 'PY', 'Paraguay', NULL, NULL, NULL),
(173, 'PE', 'Peru', NULL, NULL, NULL),
(174, 'PH', 'Philippines', NULL, NULL, NULL),
(175, 'PN', 'Pitcairn', NULL, NULL, NULL),
(176, 'PL', 'Poland', NULL, NULL, NULL),
(177, 'PT', 'Portugal', NULL, NULL, NULL),
(178, 'PR', 'Puerto Rico', NULL, NULL, NULL),
(179, 'QA', 'Qatar', NULL, NULL, NULL),
(180, 'RE', 'Reunion', NULL, NULL, NULL),
(181, 'RO', 'Romania', NULL, NULL, NULL),
(182, 'RU', 'Russian Federation', NULL, NULL, NULL),
(183, 'RW', 'Rwanda', NULL, NULL, NULL),
(184, 'KN', 'Saint Kitts and Nevis', NULL, NULL, NULL),
(185, 'LC', 'Saint Lucia', NULL, NULL, NULL),
(186, 'VC', 'Saint Vincent and the Grenadines', NULL, NULL, NULL),
(187, 'WS', 'Samoa', NULL, NULL, NULL),
(188, 'SM', 'San Marino', NULL, NULL, NULL),
(189, 'ST', 'Sao Tome and Principe', NULL, NULL, NULL),
(190, 'SA', 'Saudi Arabia', NULL, NULL, NULL),
(191, 'SN', 'Senegal', NULL, NULL, NULL),
(192, 'RS', 'Serbia', NULL, NULL, NULL),
(193, 'SC', 'Seychelles', NULL, NULL, NULL),
(194, 'SL', 'Sierra Leone', NULL, NULL, NULL),
(195, 'SG', 'Singapore', NULL, NULL, NULL),
(196, 'SK', 'Slovakia', NULL, NULL, NULL),
(197, 'SI', 'Slovenia', NULL, NULL, NULL),
(198, 'SB', 'Solomon Islands', NULL, NULL, NULL),
(199, 'SO', 'Somalia', NULL, NULL, NULL),
(200, 'ZA', 'South Africa', NULL, NULL, NULL),
(201, 'GS', 'South Georgia South Sandwich Islands', NULL, NULL, NULL),
(202, 'ES', 'Spain', NULL, NULL, NULL),
(203, 'LK', 'Sri Lanka', NULL, NULL, NULL),
(204, 'SH', 'St. Helena', NULL, NULL, NULL),
(205, 'PM', 'St. Pierre and Miquelon', NULL, NULL, NULL),
(206, 'SD', 'Sudan', NULL, NULL, NULL),
(207, 'SR', 'Suriname', NULL, NULL, NULL),
(208, 'SJ', 'Svalbard and Jan Mayen Islands', NULL, NULL, NULL),
(209, 'SZ', 'Swaziland', NULL, NULL, NULL),
(210, 'SE', 'Sweden', NULL, NULL, NULL),
(211, 'CH', 'Switzerland', NULL, NULL, NULL),
(212, 'SY', 'Syrian Arab Republic', NULL, NULL, NULL),
(213, 'TW', 'Taiwan', NULL, NULL, NULL),
(214, 'TJ', 'Tajikistan', NULL, NULL, NULL),
(215, 'TZ', 'Tanzania, United Republic of', NULL, NULL, NULL),
(216, 'TH', 'Thailand', NULL, NULL, NULL),
(217, 'TG', 'Togo', NULL, NULL, NULL),
(218, 'TK', 'Tokelau', NULL, NULL, NULL),
(219, 'TO', 'Tonga', NULL, NULL, NULL),
(220, 'TT', 'Trinidad and Tobago', NULL, NULL, NULL),
(221, 'TN', 'Tunisia', NULL, NULL, NULL),
(222, 'TR', 'Turkey', NULL, NULL, NULL),
(223, 'TM', 'Turkmenistan', NULL, NULL, NULL),
(224, 'TC', 'Turks and Caicos Islands', NULL, NULL, NULL),
(225, 'TV', 'Tuvalu', NULL, NULL, NULL),
(226, 'UG', 'Uganda', NULL, NULL, NULL),
(227, 'UA', 'Ukraine', NULL, NULL, NULL),
(228, 'AE', 'United Arab Emirates', NULL, NULL, NULL),
(229, 'GB', 'United Kingdom', NULL, NULL, NULL),
(230, 'US', 'United States', '108', NULL, '2018-06-25 22:27:42'),
(231, 'UM', 'United States minor outlying islands', NULL, NULL, NULL),
(232, 'UY', 'Uruguay', NULL, NULL, NULL),
(233, 'UZ', 'Uzbekistan', NULL, NULL, NULL),
(234, 'VU', 'Vanuatu', NULL, NULL, NULL),
(235, 'VA', 'Vatican City State', NULL, NULL, NULL),
(236, 'VE', 'Venezuela', NULL, NULL, NULL),
(237, 'VN', 'Vietnam', NULL, NULL, NULL),
(238, 'VG', 'Virgin Islands (British)', NULL, NULL, NULL),
(239, 'VI', 'Virgin Islands (U.S.)', NULL, NULL, NULL),
(240, 'WF', 'Wallis and Futuna Islands', NULL, NULL, NULL),
(241, 'EH', 'Western Sahara', NULL, NULL, NULL),
(242, 'YE', 'Yemen', NULL, NULL, NULL),
(243, 'ZR', 'Zaire', NULL, NULL, NULL),
(244, 'ZM', 'Zambia', NULL, NULL, NULL),
(245, 'ZW', 'Zimbabwe', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `id` int(10) UNSIGNED NOT NULL,
  `type_id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `entity_id` int(10) UNSIGNED DEFAULT NULL,
  `icon` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `class` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `assets` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`id`, `type_id`, `user_id`, `entity_id`, `icon`, `class`, `text`, `assets`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 4, 'save', 'bg-aqua', 'trans(\"history.backend.users.updated\") <strong>{user}</strong>', '{\"user_string\":\"binaya shrestha\"}', '2018-05-27 22:45:18', '2018-05-28 00:29:45'),
(2, 1, 1, 4, 'check', 'bg-green', 'trans(\"history.backend.users.confirmed\") <strong>{user}</strong>', '{\"user_string\":\"binaya shrestha\"}', '2018-05-27 22:45:29', '2018-05-28 00:29:45'),
(3, 1, 1, 4, 'trash', 'bg-maroon', 'trans(\"history.backend.users.deleted\") <strong>{user}</strong>', '{\"user_string\":\"binaya shrestha\"}', '2018-05-28 00:29:27', '2018-05-28 00:29:45'),
(4, 1, 1, 4, 'trash', 'bg-maroon', 'trans(\"history.backend.users.permanently_deleted\") <strong>{user}</strong>', '{\"user_string\":\"binaya shrestha\"}', '2018-05-28 00:29:45', '2018-05-28 00:29:45'),
(5, 1, 1, 5, 'check', 'bg-green', 'trans(\"history.backend.users.confirmed\") <strong>{user}</strong>', '{\"user_link\":[\"admin.access.user.show\",\"binaya shrestha\",5]}', '2018-05-28 01:19:34', '2018-05-28 01:19:34'),
(6, 1, 1, 6, 'check', 'bg-green', 'trans(\"history.backend.users.confirmed\") <strong>{user}</strong>', '{\"user_link\":[\"admin.access.user.show\",\"Ayaz Udin\",6]}', '2018-05-28 22:27:56', '2018-05-28 22:27:56'),
(7, 1, 1, 7, 'check', 'bg-green', 'trans(\"history.backend.users.confirmed\") <strong>{user}</strong>', '{\"user_link\":[\"admin.access.user.show\",\"Sanjeev Singh\",7]}', '2018-05-28 22:28:04', '2018-05-28 22:28:04'),
(8, 1, 1, 7, 'times', 'bg-red', 'trans(\"history.backend.users.unconfirmed\") <strong>{user}</strong>', '{\"user_link\":[\"admin.access.user.show\",\"Sanjeev Singh\",7]}', '2018-05-28 22:43:13', '2018-05-28 22:43:13'),
(9, 1, 1, 7, 'check', 'bg-green', 'trans(\"history.backend.users.confirmed\") <strong>{user}</strong>', '{\"user_link\":[\"admin.access.user.show\",\"Sanjeev Singh\",7]}', '2018-05-28 22:43:25', '2018-05-28 22:43:25');

-- --------------------------------------------------------

--
-- Table structure for table `history_types`
--

CREATE TABLE `history_types` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `history_types`
--

INSERT INTO `history_types` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'User', '2018-04-30 01:45:23', '2018-04-30 01:45:23'),
(2, 'Role', '2018-04-30 01:45:23', '2018-04-30 01:45:23');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2015_12_28_171741_create_social_logins_table', 1),
(4, '2015_12_29_015055_setup_access_tables', 1),
(5, '2016_07_03_062439_create_history_tables', 1),
(6, '2017_04_04_131153_create_sessions_table', 1),
(7, '2018_04_30_073258_create_posts_table', 2),
(8, '2018_04_30_073409_create_artists_table', 2),
(13, '2018_05_10_045318_create_postmetas_table', 3),
(14, '2018_05_10_045416_create_postcats_table', 3),
(15, '2018_05_11_043836_create_cat_relations_table', 4),
(16, '2018_05_21_065129_create_exchange_rates_table', 5),
(17, '2018_05_24_071036_add_description_to_postcats', 6),
(18, '2018_05_29_041756_create_buyers_allocations_table', 7),
(21, '2018_07_02_054228_create_stocks_table', 8),
(24, '2018_07_25_071037_create_orders_table', 9);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `cart` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `created_at`, `updated_at`, `user_id`, `cart`, `address`, `name`, `payment_id`, `status`) VALUES
(4, '2018-08-01 04:51:53', '2018-08-01 05:12:35', 5, 'O:15:\"App\\Models\\Cart\":3:{s:5:\"items\";a:2:{i:21;a:3:{s:3:\"qty\";i:3;s:5:\"price\";s:4:\"9.72\";s:4:\"item\";O:20:\"App\\Models\\Post\\Post\":25:{s:8:\"\0*\0table\";s:5:\"posts\";s:11:\"\0*\0fillable\";a:6:{i:0;s:5:\"title\";i:1;s:4:\"name\";i:2;s:7:\"content\";i:3;s:9:\"clean_url\";i:4;s:5:\"image\";i:5;s:6:\"status\";}s:13:\"\0*\0connection\";s:5:\"mysql\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:13:\"\0*\0attributes\";a:18:{s:2:\"id\";i:21;s:6:\"userid\";i:1;s:5:\"title\";s:18:\"Kalachakra Mandala\";s:4:\"name\";s:18:\"Kalachakra Mandala\";s:7:\"excerpt\";s:567:\"Kalachakra mandala is the “Palace of Purity”with more than seven hundred deities residing inside ,represented by various signs and symbols .The entrances of the palace  nearest to the centre are  said to be cittacakra(mind-wheels),and the middle entrances are said to be vakcakra(voice-wheels).Outside the gates of vakcakra are figures of various animals,including a corpse,and marigold-like lotus flower.They include a deer,buffalo,ram peacock,elephant,mongoose ,bull,makara,mouse,and the Garuda.They are the vehicles of various divinities of the Hindu pantheon.\";s:7:\"content\";s:1663:\"<p>It is reported that in the year after Buddha Shakyamuni attained Enlightenment,he was asked by King Chandrabhadra of Shambhala to teach the Kalachakra Tantra.The Buddha manifested himself in the form of the Kalachakra meditational deity and gave the full teachings and initiation of this tantra.The kalachakra teaching was then transmitted through a lineage of seven kings and 25&nbsp; propagators.</p>\r\n<p>Kalachakra mandala is the &ldquo;Palace of Purity&rdquo;with more than seven hundred deities residing inside ,represented by various signs and symbols .The entrances of the palace&nbsp; nearest to the centre are&nbsp; said to be cittacakra(mind-wheels),and the middle entrances are said to be vakcakra(voice-wheels).Outside the gates of vakcakra are figures of various animals,including a corpse,and marigold-like lotus flower.They include a deer,buffalo,ram peacock,elephant,mongoose ,bull,makara,mouse,and the Garuda.They are the vehicles of various divinities of the Hindu pantheon.</p>\r\n<p>The outermost gates belong to the third circle called kayacakra(body-wheels).There are four gates and four chariots one in each gate.You can see boars drawing a chariot at the eastern gate,horses drawing the chariot at the southern gate,elephants at the western gate and lions drawing the chariot at the northern gate.</p>\r\n<p>Kalachakra Mandala is one of the most complicated forms of Tibetan mandalas which is used as a device for meditation and which is worshipped for the betterment of all the sentient beings.It also represents the cosmos system which consists of the five major elements of life. Namely &ndash; Fire , Earth , Water , Air and Space .</p>\";s:9:\"clean_url\";s:18:\"kalachakra-mandala\";s:9:\"post_type\";s:7:\"product\";s:5:\"image\";s:32:\"/photos/1/products/mandala-2.jpg\";s:10:\"menu_order\";N;s:9:\"cmt_count\";N;s:6:\"status\";s:1:\"1\";s:10:\"created_at\";s:19:\"2018-06-25 15:22:32\";s:10:\"updated_at\";s:19:\"2018-06-27 22:49:32\";s:5:\"price\";s:5:\"3.241\";s:3:\"qty\";s:1:\"3\";s:7:\"brocade\";s:2:\"20\";s:6:\"handle\";s:2:\"19\";}s:11:\"\0*\0original\";a:14:{s:2:\"id\";i:21;s:6:\"userid\";i:1;s:5:\"title\";s:18:\"Kalachakra Mandala\";s:4:\"name\";s:18:\"Kalachakra Mandala\";s:7:\"excerpt\";s:567:\"Kalachakra mandala is the “Palace of Purity”with more than seven hundred deities residing inside ,represented by various signs and symbols .The entrances of the palace  nearest to the centre are  said to be cittacakra(mind-wheels),and the middle entrances are said to be vakcakra(voice-wheels).Outside the gates of vakcakra are figures of various animals,including a corpse,and marigold-like lotus flower.They include a deer,buffalo,ram peacock,elephant,mongoose ,bull,makara,mouse,and the Garuda.They are the vehicles of various divinities of the Hindu pantheon.\";s:7:\"content\";s:1663:\"<p>It is reported that in the year after Buddha Shakyamuni attained Enlightenment,he was asked by King Chandrabhadra of Shambhala to teach the Kalachakra Tantra.The Buddha manifested himself in the form of the Kalachakra meditational deity and gave the full teachings and initiation of this tantra.The kalachakra teaching was then transmitted through a lineage of seven kings and 25&nbsp; propagators.</p>\r\n<p>Kalachakra mandala is the &ldquo;Palace of Purity&rdquo;with more than seven hundred deities residing inside ,represented by various signs and symbols .The entrances of the palace&nbsp; nearest to the centre are&nbsp; said to be cittacakra(mind-wheels),and the middle entrances are said to be vakcakra(voice-wheels).Outside the gates of vakcakra are figures of various animals,including a corpse,and marigold-like lotus flower.They include a deer,buffalo,ram peacock,elephant,mongoose ,bull,makara,mouse,and the Garuda.They are the vehicles of various divinities of the Hindu pantheon.</p>\r\n<p>The outermost gates belong to the third circle called kayacakra(body-wheels).There are four gates and four chariots one in each gate.You can see boars drawing a chariot at the eastern gate,horses drawing the chariot at the southern gate,elephants at the western gate and lions drawing the chariot at the northern gate.</p>\r\n<p>Kalachakra Mandala is one of the most complicated forms of Tibetan mandalas which is used as a device for meditation and which is worshipped for the betterment of all the sentient beings.It also represents the cosmos system which consists of the five major elements of life. Namely &ndash; Fire , Earth , Water , Air and Space .</p>\";s:9:\"clean_url\";s:18:\"kalachakra-mandala\";s:9:\"post_type\";s:7:\"product\";s:5:\"image\";s:32:\"/photos/1/products/mandala-2.jpg\";s:10:\"menu_order\";N;s:9:\"cmt_count\";N;s:6:\"status\";s:1:\"1\";s:10:\"created_at\";s:19:\"2018-06-25 15:22:32\";s:10:\"updated_at\";s:19:\"2018-06-27 22:49:32\";}s:8:\"\0*\0casts\";a:0:{}s:8:\"\0*\0dates\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:9:\"\0*\0events\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:10:\"timestamps\";b:1;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}i:31;a:3:{s:3:\"qty\";i:2;s:5:\"price\";s:5:\"12.96\";s:4:\"item\";O:20:\"App\\Models\\Post\\Post\":25:{s:8:\"\0*\0table\";s:5:\"posts\";s:11:\"\0*\0fillable\";a:6:{i:0;s:5:\"title\";i:1;s:4:\"name\";i:2;s:7:\"content\";i:3;s:9:\"clean_url\";i:4;s:5:\"image\";i:5;s:6:\"status\";}s:13:\"\0*\0connection\";s:5:\"mysql\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:13:\"\0*\0attributes\";a:18:{s:2:\"id\";i:31;s:6:\"userid\";i:1;s:5:\"title\";s:25:\"Mandala with Brown Circle\";s:4:\"name\";s:25:\"Mandala with Brown Circle\";s:7:\"excerpt\";N;s:7:\"content\";N;s:9:\"clean_url\";s:25:\"mandala-with-brown-circle\";s:9:\"post_type\";s:7:\"product\";s:5:\"image\";s:36:\"/photos/1/products/Mandala 8-min.JPG\";s:10:\"menu_order\";N;s:9:\"cmt_count\";N;s:6:\"status\";s:1:\"1\";s:10:\"created_at\";s:19:\"2018-06-29 19:23:23\";s:10:\"updated_at\";s:19:\"2018-06-29 19:23:23\";s:5:\"price\";s:5:\"6.482\";s:3:\"qty\";s:1:\"2\";s:7:\"brocade\";s:2:\"20\";s:6:\"handle\";s:2:\"19\";}s:11:\"\0*\0original\";a:14:{s:2:\"id\";i:31;s:6:\"userid\";i:1;s:5:\"title\";s:25:\"Mandala with Brown Circle\";s:4:\"name\";s:25:\"Mandala with Brown Circle\";s:7:\"excerpt\";N;s:7:\"content\";N;s:9:\"clean_url\";s:25:\"mandala-with-brown-circle\";s:9:\"post_type\";s:7:\"product\";s:5:\"image\";s:36:\"/photos/1/products/Mandala 8-min.JPG\";s:10:\"menu_order\";N;s:9:\"cmt_count\";N;s:6:\"status\";s:1:\"1\";s:10:\"created_at\";s:19:\"2018-06-29 19:23:23\";s:10:\"updated_at\";s:19:\"2018-06-29 19:23:23\";}s:8:\"\0*\0casts\";a:0:{}s:8:\"\0*\0dates\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:9:\"\0*\0events\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:10:\"timestamps\";b:1;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}}s:8:\"totalQty\";i:2;s:10:\"totalPrice\";d:22.68;}', '525 W. Windsor Rd.', 'binaya shrestha', 'ch_1CuHhGARIo5dUBNH9y5elvlj', 'success'),
(5, '2018-08-01 04:56:23', '2018-08-01 04:56:23', 5, 'O:15:\"App\\Models\\Cart\":3:{s:5:\"items\";a:1:{i:29;a:3:{s:3:\"qty\";i:5;s:5:\"price\";s:6:\"810.18\";s:4:\"item\";O:20:\"App\\Models\\Post\\Post\":25:{s:8:\"\0*\0table\";s:5:\"posts\";s:11:\"\0*\0fillable\";a:6:{i:0;s:5:\"title\";i:1;s:4:\"name\";i:2;s:7:\"content\";i:3;s:9:\"clean_url\";i:4;s:5:\"image\";i:5;s:6:\"status\";}s:13:\"\0*\0connection\";s:5:\"mysql\";s:13:\"\0*\0primaryKey\";s:2:\"id\";s:10:\"\0*\0keyType\";s:3:\"int\";s:12:\"incrementing\";b:1;s:7:\"\0*\0with\";a:0:{}s:12:\"\0*\0withCount\";a:0:{}s:10:\"\0*\0perPage\";i:15;s:6:\"exists\";b:1;s:18:\"wasRecentlyCreated\";b:0;s:13:\"\0*\0attributes\";a:18:{s:2:\"id\";i:29;s:6:\"userid\";i:1;s:5:\"title\";s:27:\"Mandala with Red Background\";s:4:\"name\";s:27:\"Mandala with Red Background\";s:7:\"excerpt\";N;s:7:\"content\";N;s:9:\"clean_url\";s:27:\"mandala-with-red-background\";s:9:\"post_type\";s:7:\"product\";s:5:\"image\";s:37:\"/photos/1/products/Mandala 10-min.JPG\";s:10:\"menu_order\";N;s:9:\"cmt_count\";N;s:6:\"status\";s:1:\"1\";s:10:\"created_at\";s:19:\"2018-06-29 19:18:55\";s:10:\"updated_at\";s:19:\"2018-06-29 19:18:55\";s:5:\"price\";s:7:\"162.036\";s:3:\"qty\";s:1:\"5\";s:7:\"brocade\";s:2:\"20\";s:6:\"handle\";s:2:\"19\";}s:11:\"\0*\0original\";a:14:{s:2:\"id\";i:29;s:6:\"userid\";i:1;s:5:\"title\";s:27:\"Mandala with Red Background\";s:4:\"name\";s:27:\"Mandala with Red Background\";s:7:\"excerpt\";N;s:7:\"content\";N;s:9:\"clean_url\";s:27:\"mandala-with-red-background\";s:9:\"post_type\";s:7:\"product\";s:5:\"image\";s:37:\"/photos/1/products/Mandala 10-min.JPG\";s:10:\"menu_order\";N;s:9:\"cmt_count\";N;s:6:\"status\";s:1:\"1\";s:10:\"created_at\";s:19:\"2018-06-29 19:18:55\";s:10:\"updated_at\";s:19:\"2018-06-29 19:18:55\";}s:8:\"\0*\0casts\";a:0:{}s:8:\"\0*\0dates\";a:0:{}s:13:\"\0*\0dateFormat\";N;s:10:\"\0*\0appends\";a:0:{}s:9:\"\0*\0events\";a:0:{}s:14:\"\0*\0observables\";a:0:{}s:12:\"\0*\0relations\";a:0:{}s:10:\"\0*\0touches\";a:0:{}s:10:\"timestamps\";b:1;s:9:\"\0*\0hidden\";a:0:{}s:10:\"\0*\0visible\";a:0:{}s:10:\"\0*\0guarded\";a:1:{i:0;s:1:\"*\";}}}}s:8:\"totalQty\";i:1;s:10:\"totalPrice\";d:810.17999999999995;}', '525 W. Windsor Rd.', 'sanjay shrestha', 'ch_1CuHldARIo5dUBNHXmxIZovF', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `display_name`, `created_at`, `updated_at`) VALUES
(1, 'view-backend', 'View Backend', '2018-04-30 01:45:21', '2018-04-30 01:45:21');

-- --------------------------------------------------------

--
-- Table structure for table `permission_role`
--

CREATE TABLE `permission_role` (
  `id` int(10) UNSIGNED NOT NULL,
  `permission_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permission_role`
--

INSERT INTO `permission_role` (`id`, `permission_id`, `role_id`) VALUES
(1, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `postcats`
--

CREATE TABLE `postcats` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent` int(11) NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `catorder` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `postcats`
--

INSERT INTO `postcats` (`id`, `parent`, `type`, `name`, `slug`, `image`, `catorder`, `created_at`, `updated_at`, `description`) VALUES
(8, 0, 'post_category', 'Post Category', 'post-category', NULL, NULL, '2018-05-21 00:05:32', '2018-05-21 00:05:32', NULL),
(10, 0, 'banner_category', 'Home Banner', 'home-banner', NULL, NULL, '2018-05-21 23:48:15', '2018-05-21 23:48:15', NULL),
(11, 0, 'brocade_category', 'Brocade Category', 'brocade-category', '/photos/1/hawks-landing-bungalow-wolf-custom-homes-4092410 (1).jpeg', NULL, '2018-05-22 23:54:29', '2018-05-22 23:54:29', NULL),
(13, 0, 'category', 'Full Gold Style', 'full-gold-style', '/photos/1/category/Full-Gold-Style.jpg', NULL, '2018-06-11 04:54:43', '2018-07-01 21:28:31', 'The Tibetan vision of Amitabha is the Buddha of Boundless lightSukhavati the Blissful which is also called the Pure Land. Amitabha Buddha,'),
(14, 0, 'category', 'Mandalas', 'mandalas', '/photos/1/category/Mandalas.jpg', NULL, '2018-06-11 04:55:15', '2018-07-01 22:08:54', 'The Tibetan vision of Amitabha is the Buddha of Boundless lightSukhavati the Blissful which is also called the Pure Land. Amitabha Buddha,'),
(15, 0, 'category', 'Wheel of Life', 'wheel-of-life', '/photos/1/category/Wheel-of-Life.jpg', NULL, '2018-06-11 04:55:59', '2018-07-01 21:53:19', 'The Tibetan vision of Amitabha is the Buddha of Boundless lightSukhavati the Blissful which is also called the Pure Land. Amitabha Buddha,'),
(16, 0, 'category', 'Buddha and Boddhisattvas', 'buddha-and-boddhisattvas', '/photos/1/category/Buddha-and-Boddhisattva-thangka.jpg', NULL, '2018-06-11 04:56:19', '2018-06-28 16:28:28', 'The Tibetan vision of Amitabha is the Buddha of Boundless lightSukhavati the Blissful which is also called the Pure Land. Amitabha Buddha,'),
(17, 0, 'category', 'Japanese style', 'japanese-style', '/photos/1/category/japanese-style.jpg', NULL, '2018-06-11 04:56:43', '2018-07-02 11:19:44', 'The Tibetan vision of Amitabha is the Buddha of Boundless lightSukhavati the Blissful which is also called the Pure Land. Amitabha Buddha,'),
(18, 0, 'category', 'Black and White Thangka', 'black-and-white-thangka', '/photos/1/category/Black-and-White-Style.jpg', NULL, '2018-06-11 04:57:04', '2018-07-02 12:00:20', 'The Tibetan vision of Amitabha is the Buddha of Boundless lightSukhavati the Blissful which is also called the Pure Land. Amitabha Buddha,'),
(19, 0, 'category', 'Newari Style', 'newari-style', '/photos/1/category/newari-style.jpg', NULL, '2018-06-11 04:57:28', '2018-07-02 11:20:09', 'The Tibetan vision of Amitabha is the Buddha of Boundless lightSukhavati the Blissful which is also called the Pure Land. Amitabha Buddha,'),
(20, 0, 'category', 'Dharmapalas', 'dharmapalas', '/photos/1/9439 (1).jpg', NULL, '2018-06-11 04:58:21', '2018-07-15 12:16:00', 'The Tibetan vision of Amitabha is the Buddha of Boundless lightSukhavati the Blissful which is also called the Pure Land. Amitabha Buddha,'),
(21, 0, 'category', 'Yidams', 'yidams', '/photos/1/category/yidams-thangka.jpg', NULL, '2018-06-11 04:58:39', '2018-07-02 11:28:12', 'The Tibetan vision of Amitabha is the Buddha of Boundless lightSukhavati the Blissful which is also called the Pure Land. Amitabha Buddha,'),
(22, 0, 'category', 'Buddha Life Story', 'buddha-life-story', '/photos/1/category/Buddha-Life-Story.jpg', NULL, '2018-06-11 04:58:59', '2018-07-01 21:55:03', 'The Tibetan vision of Amitabha is the Buddha of Boundless lightSukhavati the Blissful which is also called the Pure Land. Amitabha Buddha,'),
(23, 0, 'category', 'Brocade Mounted Thangkas', 'brocade-mounted-thangkas', '/photos/1/category/Brocade-Mounted-Thangkas.jpg', NULL, '2018-06-28 11:39:13', '2018-07-01 22:02:10', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `postmetas`
--

CREATE TABLE `postmetas` (
  `id` int(10) UNSIGNED NOT NULL,
  `postid` int(11) NOT NULL,
  `meta_key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `meta_value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `postmetas`
--

INSERT INTO `postmetas` (`id`, `postid`, `meta_key`, `meta_value`, `created_at`, `updated_at`) VALUES
(3, 4, 'keywords', 'Lorem Ipsum Lorem Ipsum', '2018-05-15 04:29:28', '2018-05-15 04:40:18'),
(4, 4, 'metadesc', 'Lorem Ipsum Lorem Ipsum', '2018-05-15 04:29:28', '2018-05-15 04:40:18'),
(5, 6, 'keywords', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', '2018-05-15 23:01:38', '2018-05-15 23:10:50'),
(6, 6, 'metadesc', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', '2018-05-15 23:01:38', '2018-05-15 23:10:50'),
(7, 7, 'keywords', '', '2018-05-15 23:38:26', '2018-05-15 23:38:26'),
(8, 7, 'metadesc', '', '2018-05-15 23:38:26', '2018-05-15 23:38:26'),
(45, 12, 'options', 'a:1:{i:0;a:3:{s:4:\"name\";N;s:7:\"options\";N;s:6:\"prices\";N;}}', '2018-05-17 23:23:07', '2018-06-28 16:23:37'),
(46, 12, 'code', '5288', '2018-05-17 23:23:07', '2018-05-17 23:23:07'),
(47, 12, 'weight', '', '2018-05-17 23:23:07', '2018-05-17 23:23:07'),
(48, 12, 'size', '', '2018-05-17 23:23:07', '2018-05-17 23:23:07'),
(49, 12, 'material', '', '2018-05-17 23:23:07', '2018-05-17 23:23:07'),
(50, 12, 'price', '', '2018-05-17 23:23:07', '2018-05-17 23:23:07'),
(51, 12, 'keywords', '', '2018-05-17 23:23:07', '2018-05-17 23:23:07'),
(52, 12, 'metadesc', '', '2018-05-17 23:23:07', '2018-05-17 23:23:07'),
(53, 12, 'images', 'a:1:{i:0;N;}', '2018-05-17 23:23:07', '2018-05-17 23:23:07'),
(55, 13, 'options', 'a:1:{i:0;a:3:{s:4:\"name\";N;s:7:\"options\";N;s:6:\"prices\";N;}}', '2018-05-22 22:57:08', '2018-05-22 22:57:30'),
(56, 13, 'code', '', '2018-05-22 22:57:08', '2018-05-22 22:57:08'),
(57, 13, 'weight', '', '2018-05-22 22:57:08', '2018-05-22 22:57:08'),
(58, 13, 'size', '', '2018-05-22 22:57:08', '2018-05-22 22:57:08'),
(59, 13, 'material', '', '2018-05-22 22:57:08', '2018-05-22 22:57:08'),
(60, 13, 'price', '', '2018-05-22 22:57:09', '2018-05-22 22:57:09'),
(61, 13, 'keywords', '', '2018-05-22 22:57:09', '2018-05-22 22:57:09'),
(62, 13, 'metadesc', '', '2018-05-22 22:57:09', '2018-05-22 22:57:09'),
(63, 13, 'related_article', 'N;', '2018-05-22 22:57:09', '2018-05-22 22:57:30'),
(64, 13, 'images', 'a:1:{i:0;N;}', '2018-05-22 22:57:09', '2018-05-22 22:57:09'),
(73, 19, 'price', '500', '2018-06-13 23:34:53', '2018-06-13 23:34:53'),
(74, 20, 'price', '100', '2018-06-13 23:35:26', '2018-06-13 23:35:26'),
(75, 1, 'keywords', '', '2018-06-14 00:23:03', '2018-06-14 00:23:03'),
(76, 1, 'metadesc', '', '2018-06-14 00:23:03', '2018-06-14 00:23:03'),
(77, 5, 'keywords', '', '2018-06-14 00:23:10', '2018-06-14 00:23:10'),
(78, 5, 'metadesc', '', '2018-06-14 00:23:11', '2018-06-14 00:23:11'),
(79, 21, 'options', 'a:1:{i:0;a:3:{s:4:\"name\";N;s:7:\"options\";N;s:6:\"prices\";N;}}', '2018-06-25 09:37:32', '2018-06-25 09:37:32'),
(80, 21, 'code', '48430', '2018-06-25 09:37:32', '2018-06-25 09:37:32'),
(81, 21, 'weight', '', '2018-06-25 09:37:32', '2018-06-25 09:37:32'),
(82, 21, 'size', '15 x 15  inches, 39 x 39 cms', '2018-06-25 09:37:32', '2018-06-25 09:37:32'),
(83, 21, 'material', '', '2018-06-25 09:37:32', '2018-06-25 09:37:32'),
(84, 21, 'price', '150', '2018-06-25 09:37:32', '2018-06-25 09:38:47'),
(85, 21, 'keywords', '', '2018-06-25 09:37:32', '2018-06-25 09:37:32'),
(86, 21, 'metadesc', '', '2018-06-25 09:37:32', '2018-06-25 09:37:32'),
(87, 21, 'related_article', 'N;', '2018-06-25 09:37:32', '2018-06-28 16:23:46'),
(88, 21, 'images', 'a:2:{i:0;s:23:\"/photos/1/48430 (2).JPG\";i:1;s:23:\"/photos/1/48430 (3).JPG\";}', '2018-06-25 09:37:32', '2018-06-25 09:37:32'),
(89, 22, 'options', 'a:1:{i:0;a:3:{s:4:\"name\";N;s:7:\"options\";N;s:6:\"prices\";N;}}', '2018-06-25 09:51:17', '2018-06-25 09:51:17'),
(90, 22, 'code', '14200', '2018-06-25 09:51:17', '2018-06-25 09:51:17'),
(91, 22, 'weight', '', '2018-06-25 09:51:17', '2018-06-25 09:51:17'),
(92, 22, 'size', '17.5 x 24.5 inches, 45 x 63 cms', '2018-06-25 09:51:17', '2018-06-25 09:51:17'),
(93, 22, 'material', '', '2018-06-25 09:51:17', '2018-06-25 09:51:17'),
(94, 22, 'price', '', '2018-06-25 09:51:17', '2018-06-25 09:51:17'),
(95, 22, 'keywords', '', '2018-06-25 09:51:17', '2018-06-25 09:51:17'),
(96, 22, 'metadesc', '', '2018-06-25 09:51:17', '2018-06-25 09:51:17'),
(97, 22, 'related_article', 'N;', '2018-06-25 09:51:17', '2018-06-25 09:51:17'),
(98, 22, 'images', 'a:6:{i:0;s:23:\"/photos/1/14200 (2).JPG\";i:1;s:23:\"/photos/1/14200 (3).JPG\";i:2;s:23:\"/photos/1/14200 (4).JPG\";i:3;s:23:\"/photos/1/14200 (5).JPG\";i:4;s:23:\"/photos/1/14200 (6).JPG\";i:5;s:23:\"/photos/1/14200 (7).JPG\";}', '2018-06-25 09:51:17', '2018-06-25 09:51:17'),
(103, 12, 'related_article', 'N;', '2018-06-28 16:23:37', '2018-06-28 16:23:37'),
(104, 12, 'antique_thanka', '0', '2018-06-28 16:23:37', '2018-06-28 16:25:15'),
(105, 12, 'popular_thanka', '0', '2018-06-28 16:23:37', '2018-06-28 16:25:16'),
(106, 12, 'feature_thanka', '0', '2018-06-28 16:23:37', '2018-06-28 16:25:16'),
(107, 12, 'on_sale', '0', '2018-06-28 16:23:37', '2018-06-28 16:25:16'),
(108, 21, 'antique_thanka', '1', '2018-06-28 16:23:46', '2018-06-28 16:23:46'),
(109, 21, 'popular_thanka', '1', '2018-06-28 16:23:46', '2018-06-28 16:23:46'),
(110, 21, 'feature_thanka', '1', '2018-06-28 16:23:46', '2018-06-28 16:23:46'),
(111, 21, 'on_sale', '1', '2018-06-28 16:23:46', '2018-06-28 16:23:46'),
(112, 22, 'antique_thanka', '1', '2018-06-28 16:24:00', '2018-06-28 16:24:00'),
(113, 22, 'popular_thanka', '1', '2018-06-28 16:24:00', '2018-06-28 16:24:00'),
(114, 22, 'feature_thanka', '1', '2018-06-28 16:24:00', '2018-06-28 16:24:00'),
(115, 22, 'on_sale', '1', '2018-06-28 16:24:00', '2018-06-28 16:24:00'),
(116, 23, 'options', 'a:1:{i:0;a:3:{s:4:\"name\";N;s:7:\"options\";N;s:6:\"prices\";N;}}', '2018-06-29 12:55:23', '2018-06-29 12:55:23'),
(117, 23, 'code', '', '2018-06-29 12:55:23', '2018-06-29 12:55:23'),
(118, 23, 'weight', '', '2018-06-29 12:55:23', '2018-06-29 12:55:23'),
(119, 23, 'size', '', '2018-06-29 12:55:23', '2018-06-29 12:55:23'),
(120, 23, 'material', '', '2018-06-29 12:55:23', '2018-06-29 12:55:23'),
(121, 23, 'price', '45000', '2018-06-29 12:55:23', '2018-06-29 13:14:26'),
(122, 23, 'keywords', 'mandala, Orange Background', '2018-06-29 12:55:23', '2018-06-29 12:55:23'),
(123, 23, 'metadesc', 'Mandala with Orange Background', '2018-06-29 12:55:23', '2018-06-29 12:55:23'),
(124, 23, 'related_article', 'N;', '2018-06-29 12:55:23', '2018-06-29 12:55:23'),
(125, 23, 'antique_thanka', '1', '2018-06-29 12:55:23', '2018-06-29 12:55:23'),
(126, 23, 'popular_thanka', '0', '2018-06-29 12:55:23', '2018-06-29 13:14:26'),
(127, 23, 'feature_thanka', '0', '2018-06-29 12:55:23', '2018-06-29 13:14:26'),
(128, 23, 'on_sale', '0', '2018-06-29 12:55:23', '2018-06-29 13:14:26'),
(129, 23, 'images', 'a:1:{i:0;N;}', '2018-06-29 12:55:23', '2018-06-29 12:55:23'),
(130, 24, 'options', 'a:1:{i:0;a:3:{s:4:\"name\";N;s:7:\"options\";N;s:6:\"prices\";N;}}', '2018-06-29 12:56:52', '2018-06-29 12:56:52'),
(131, 24, 'code', '', '2018-06-29 12:56:52', '2018-06-29 12:56:52'),
(132, 24, 'weight', '', '2018-06-29 12:56:52', '2018-06-29 12:56:52'),
(133, 24, 'size', '', '2018-06-29 12:56:52', '2018-06-29 12:56:52'),
(134, 24, 'material', '', '2018-06-29 12:56:52', '2018-06-29 12:56:52'),
(135, 24, 'price', '15000', '2018-06-29 12:56:52', '2018-06-29 13:13:54'),
(136, 24, 'keywords', 'Mandala, Green Background', '2018-06-29 12:56:52', '2018-06-29 12:56:52'),
(137, 24, 'metadesc', 'Mandala with Green Background', '2018-06-29 12:56:52', '2018-06-29 12:56:52'),
(138, 24, 'related_article', 'N;', '2018-06-29 12:56:52', '2018-06-29 12:56:52'),
(139, 24, 'antique_thanka', '1', '2018-06-29 12:56:52', '2018-06-29 12:56:52'),
(140, 24, 'popular_thanka', '0', '2018-06-29 12:56:52', '2018-06-29 13:13:54'),
(141, 24, 'feature_thanka', '1', '2018-06-29 12:56:52', '2018-06-29 12:56:52'),
(142, 24, 'on_sale', '1', '2018-06-29 12:56:52', '2018-06-29 12:56:52'),
(143, 24, 'images', 'a:1:{i:0;N;}', '2018-06-29 12:56:52', '2018-06-29 12:56:52'),
(144, 25, 'options', 'a:1:{i:0;a:3:{s:4:\"name\";N;s:7:\"options\";N;s:6:\"prices\";N;}}', '2018-06-29 13:05:36', '2018-06-29 13:05:36'),
(145, 25, 'code', '', '2018-06-29 13:05:36', '2018-06-29 13:05:36'),
(146, 25, 'weight', '', '2018-06-29 13:05:36', '2018-06-29 13:05:36'),
(147, 25, 'size', '', '2018-06-29 13:05:36', '2018-06-29 13:05:36'),
(148, 25, 'material', '', '2018-06-29 13:05:36', '2018-06-29 13:05:36'),
(149, 25, 'price', '50000', '2018-06-29 13:05:36', '2018-06-29 13:13:12'),
(150, 25, 'keywords', 'Buddha, Boddhisattvas', '2018-06-29 13:05:36', '2018-06-29 13:05:36'),
(151, 25, 'metadesc', 'Buddha and Boddhisattvas', '2018-06-29 13:05:36', '2018-06-29 13:05:36'),
(152, 25, 'related_article', 'N;', '2018-06-29 13:05:36', '2018-06-29 13:05:36'),
(153, 25, 'antique_thanka', '0', '2018-06-29 13:05:36', '2018-06-29 13:05:36'),
(154, 25, 'popular_thanka', '0', '2018-06-29 13:05:36', '2018-07-04 10:34:32'),
(155, 25, 'feature_thanka', '0', '2018-06-29 13:05:36', '2018-06-29 13:13:12'),
(156, 25, 'on_sale', '0', '2018-06-29 13:05:36', '2018-06-29 13:05:36'),
(157, 25, 'images', 'a:1:{i:0;N;}', '2018-06-29 13:05:36', '2018-06-29 13:05:36'),
(158, 26, 'options', 'a:1:{i:0;a:3:{s:4:\"name\";N;s:7:\"options\";N;s:6:\"prices\";N;}}', '2018-06-29 13:07:24', '2018-06-29 13:07:24'),
(159, 26, 'code', '', '2018-06-29 13:07:24', '2018-06-29 13:07:24'),
(160, 26, 'weight', '', '2018-06-29 13:07:24', '2018-06-29 13:07:24'),
(161, 26, 'size', '', '2018-06-29 13:07:24', '2018-06-29 13:07:24'),
(162, 26, 'material', '', '2018-06-29 13:07:24', '2018-06-29 13:07:24'),
(163, 26, 'price', '20000', '2018-06-29 13:07:24', '2018-06-29 13:12:40'),
(164, 26, 'keywords', 'Mandala, Bluish Background', '2018-06-29 13:07:24', '2018-06-29 13:07:24'),
(165, 26, 'metadesc', 'Mandala with Bluish Background', '2018-06-29 13:07:24', '2018-06-29 13:07:24'),
(166, 26, 'related_article', 'N;', '2018-06-29 13:07:24', '2018-06-29 13:07:24'),
(167, 26, 'antique_thanka', '0', '2018-06-29 13:07:24', '2018-06-29 13:07:24'),
(168, 26, 'popular_thanka', '1', '2018-06-29 13:07:24', '2018-06-29 13:07:44'),
(169, 26, 'feature_thanka', '0', '2018-06-29 13:07:24', '2018-06-29 13:07:24'),
(170, 26, 'on_sale', '0', '2018-06-29 13:07:24', '2018-06-29 13:07:24'),
(171, 26, 'images', 'a:1:{i:0;N;}', '2018-06-29 13:07:24', '2018-06-29 13:07:24'),
(172, 27, 'options', 'a:1:{i:0;a:3:{s:4:\"name\";N;s:7:\"options\";N;s:6:\"prices\";N;}}', '2018-06-29 13:12:20', '2018-06-29 13:12:20'),
(173, 27, 'code', '', '2018-06-29 13:12:20', '2018-06-29 13:12:20'),
(174, 27, 'weight', '', '2018-06-29 13:12:20', '2018-06-29 13:12:20'),
(175, 27, 'size', '', '2018-06-29 13:12:20', '2018-06-29 13:12:20'),
(176, 27, 'material', '', '2018-06-29 13:12:20', '2018-06-29 13:12:20'),
(177, 27, 'price', '10000', '2018-06-29 13:12:20', '2018-06-29 13:12:20'),
(178, 27, 'keywords', 'Mandala, Yellow Background', '2018-06-29 13:12:20', '2018-06-29 13:12:20'),
(179, 27, 'metadesc', 'Mandala with Yellow Background', '2018-06-29 13:12:20', '2018-06-29 13:12:20'),
(180, 27, 'related_article', 'N;', '2018-06-29 13:12:20', '2018-06-29 13:12:20'),
(181, 27, 'antique_thanka', '0', '2018-06-29 13:12:20', '2018-06-29 13:12:20'),
(182, 27, 'popular_thanka', '1', '2018-06-29 13:12:20', '2018-06-29 13:12:20'),
(183, 27, 'feature_thanka', '0', '2018-06-29 13:12:20', '2018-06-29 13:12:20'),
(184, 27, 'on_sale', '0', '2018-06-29 13:12:20', '2018-06-29 13:12:20'),
(185, 27, 'images', 'a:1:{i:0;N;}', '2018-06-29 13:12:20', '2018-06-29 13:12:20'),
(186, 28, 'options', 'a:1:{i:0;a:3:{s:4:\"name\";N;s:7:\"options\";N;s:6:\"prices\";N;}}', '2018-06-29 13:17:37', '2018-06-29 13:17:37'),
(187, 28, 'code', '', '2018-06-29 13:17:37', '2018-06-29 13:17:37'),
(188, 28, 'weight', '', '2018-06-29 13:17:37', '2018-06-29 13:17:37'),
(189, 28, 'size', '', '2018-06-29 13:17:37', '2018-06-29 13:17:37'),
(190, 28, 'material', '', '2018-06-29 13:17:37', '2018-06-29 13:17:37'),
(191, 28, 'price', '18000', '2018-06-29 13:17:37', '2018-06-29 13:17:37'),
(192, 28, 'keywords', 'Mandala, Yellow Circle', '2018-06-29 13:17:37', '2018-06-29 13:17:37'),
(193, 28, 'metadesc', 'Mandala with Yellow Circle', '2018-06-29 13:17:37', '2018-06-29 13:17:37'),
(194, 28, 'related_article', 'N;', '2018-06-29 13:17:37', '2018-06-29 13:17:37'),
(195, 28, 'antique_thanka', '0', '2018-06-29 13:17:37', '2018-06-29 13:17:37'),
(196, 28, 'popular_thanka', '0', '2018-06-29 13:17:37', '2018-06-29 13:17:37'),
(197, 28, 'feature_thanka', '1', '2018-06-29 13:17:37', '2018-06-29 13:17:37'),
(198, 28, 'on_sale', '0', '2018-06-29 13:17:37', '2018-06-29 13:17:37'),
(199, 28, 'images', 'a:1:{i:0;N;}', '2018-06-29 13:17:37', '2018-06-29 13:17:37'),
(200, 29, 'options', 'a:1:{i:0;a:3:{s:4:\"name\";N;s:7:\"options\";N;s:6:\"prices\";N;}}', '2018-06-29 13:33:55', '2018-06-29 13:33:55'),
(201, 29, 'code', '', '2018-06-29 13:33:55', '2018-06-29 13:33:55'),
(202, 29, 'weight', '', '2018-06-29 13:33:55', '2018-06-29 13:33:55'),
(203, 29, 'size', '', '2018-06-29 13:33:55', '2018-06-29 13:33:55'),
(204, 29, 'material', '', '2018-06-29 13:33:55', '2018-06-29 13:33:55'),
(205, 29, 'price', '25000', '2018-06-29 13:33:55', '2018-06-29 13:33:55'),
(206, 29, 'keywords', 'Mandala, Red Background', '2018-06-29 13:33:55', '2018-06-29 13:33:55'),
(207, 29, 'metadesc', 'Mandala with Red Background', '2018-06-29 13:33:55', '2018-06-29 13:33:55'),
(208, 29, 'related_article', 'N;', '2018-06-29 13:33:55', '2018-06-29 13:33:55'),
(209, 29, 'antique_thanka', '0', '2018-06-29 13:33:55', '2018-06-29 13:33:55'),
(210, 29, 'popular_thanka', '0', '2018-06-29 13:33:55', '2018-06-29 13:33:55'),
(211, 29, 'feature_thanka', '1', '2018-06-29 13:33:55', '2018-06-29 13:33:55'),
(212, 29, 'on_sale', '0', '2018-06-29 13:33:55', '2018-06-29 13:33:55'),
(213, 29, 'images', 'a:1:{i:0;N;}', '2018-06-29 13:33:55', '2018-06-29 13:33:55'),
(214, 30, 'options', 'a:1:{i:0;a:3:{s:4:\"name\";N;s:7:\"options\";N;s:6:\"prices\";N;}}', '2018-06-29 13:36:43', '2018-06-29 13:36:43'),
(215, 30, 'code', '', '2018-06-29 13:36:43', '2018-06-29 13:36:43'),
(216, 30, 'weight', '', '2018-06-29 13:36:43', '2018-06-29 13:36:43'),
(217, 30, 'size', '', '2018-06-29 13:36:43', '2018-06-29 13:36:43'),
(218, 30, 'material', '', '2018-06-29 13:36:43', '2018-06-29 13:36:43'),
(219, 30, 'price', '18000', '2018-06-29 13:36:43', '2018-06-29 13:36:43'),
(220, 30, 'keywords', 'Mandala, Red Circle', '2018-06-29 13:36:43', '2018-06-29 13:36:43'),
(221, 30, 'metadesc', 'Mandala with Red Circle', '2018-06-29 13:36:43', '2018-06-29 13:36:43'),
(222, 30, 'related_article', 'N;', '2018-06-29 13:36:43', '2018-06-29 13:36:43'),
(223, 30, 'antique_thanka', '0', '2018-06-29 13:36:43', '2018-06-29 13:36:43'),
(224, 30, 'popular_thanka', '1', '2018-06-29 13:36:43', '2018-06-29 13:37:02'),
(225, 30, 'feature_thanka', '0', '2018-06-29 13:36:43', '2018-06-29 13:36:43'),
(226, 30, 'on_sale', '0', '2018-06-29 13:36:43', '2018-06-29 13:36:43'),
(227, 30, 'images', 'a:1:{i:0;N;}', '2018-06-29 13:36:43', '2018-06-29 13:36:43'),
(228, 31, 'options', 'a:1:{i:0;a:3:{s:4:\"name\";N;s:7:\"options\";N;s:6:\"prices\";N;}}', '2018-06-29 13:38:23', '2018-06-29 13:38:23'),
(229, 31, 'code', '', '2018-06-29 13:38:23', '2018-06-29 13:38:23'),
(230, 31, 'weight', '', '2018-06-29 13:38:23', '2018-06-29 13:38:23'),
(231, 31, 'size', '', '2018-06-29 13:38:23', '2018-06-29 13:38:23'),
(232, 31, 'material', '', '2018-06-29 13:38:23', '2018-06-29 13:38:23'),
(233, 31, 'price', '16000', '2018-06-29 13:38:23', '2018-06-29 13:41:35'),
(234, 31, 'keywords', 'Mandala, Brown Circle', '2018-06-29 13:38:23', '2018-06-29 13:38:23'),
(235, 31, 'metadesc', 'Mandala with Brown Circle', '2018-06-29 13:38:23', '2018-06-29 13:38:23'),
(236, 31, 'related_article', 'N;', '2018-06-29 13:38:23', '2018-06-29 13:38:23'),
(237, 31, 'antique_thanka', '0', '2018-06-29 13:38:23', '2018-06-29 13:38:23'),
(238, 31, 'popular_thanka', '0', '2018-06-29 13:38:23', '2018-06-29 13:38:23'),
(239, 31, 'feature_thanka', '1', '2018-06-29 13:38:23', '2018-06-29 13:38:23'),
(240, 31, 'on_sale', '0', '2018-06-29 13:38:23', '2018-06-29 13:38:23'),
(241, 31, 'images', 'a:1:{i:0;N;}', '2018-06-29 13:38:23', '2018-06-29 13:38:23'),
(242, 32, 'options', 'a:1:{i:0;a:3:{s:4:\"name\";N;s:7:\"options\";N;s:6:\"prices\";N;}}', '2018-06-29 13:40:04', '2018-06-29 13:40:04'),
(243, 32, 'code', '', '2018-06-29 13:40:04', '2018-06-29 13:40:04'),
(244, 32, 'weight', '', '2018-06-29 13:40:04', '2018-06-29 13:40:04'),
(245, 32, 'size', '', '2018-06-29 13:40:04', '2018-06-29 13:40:04'),
(246, 32, 'material', '', '2018-06-29 13:40:04', '2018-06-29 13:40:04'),
(247, 32, 'price', '7500', '2018-06-29 13:40:04', '2018-06-29 13:40:04'),
(248, 32, 'keywords', 'Mandala, Black Circle', '2018-06-29 13:40:04', '2018-06-29 13:40:04'),
(249, 32, 'metadesc', 'Mandala with Black Circle', '2018-06-29 13:40:04', '2018-06-29 13:40:04'),
(250, 32, 'related_article', 'N;', '2018-06-29 13:40:04', '2018-06-29 13:40:04'),
(251, 32, 'antique_thanka', '0', '2018-06-29 13:40:04', '2018-06-29 13:40:04'),
(252, 32, 'popular_thanka', '0', '2018-06-29 13:40:04', '2018-06-29 13:40:04'),
(253, 32, 'feature_thanka', '0', '2018-06-29 13:40:04', '2018-06-29 13:40:04'),
(254, 32, 'on_sale', '1', '2018-06-29 13:40:04', '2018-06-29 13:40:04'),
(255, 32, 'images', 'a:1:{i:0;N;}', '2018-06-29 13:40:04', '2018-06-29 13:40:04'),
(256, 33, 'options', 'a:1:{i:0;a:3:{s:4:\"name\";N;s:7:\"options\";N;s:6:\"prices\";N;}}', '2018-07-04 11:05:04', '2018-07-04 11:05:04'),
(257, 33, 'code', '50198', '2018-07-04 11:05:04', '2018-07-04 11:05:04'),
(258, 33, 'weight', '', '2018-07-04 11:05:04', '2018-07-04 11:05:04'),
(259, 33, 'size', '20 x 30 inches, 51 x 76 cms', '2018-07-04 11:05:04', '2018-07-04 11:05:04'),
(260, 33, 'material', '', '2018-07-04 11:05:04', '2018-07-04 11:05:04'),
(261, 33, 'price', '', '2018-07-04 11:05:04', '2018-07-04 11:05:04'),
(262, 33, 'keywords', '', '2018-07-04 11:05:04', '2018-07-04 11:05:04'),
(263, 33, 'metadesc', '', '2018-07-04 11:05:04', '2018-07-04 11:05:04'),
(264, 33, 'related_article', 'N;', '2018-07-04 11:05:04', '2018-07-04 11:05:04'),
(265, 33, 'antique_thanka', '0', '2018-07-04 11:05:04', '2018-07-04 11:05:04'),
(266, 33, 'popular_thanka', '1', '2018-07-04 11:05:04', '2018-07-04 11:05:04'),
(267, 33, 'feature_thanka', '0', '2018-07-04 11:05:04', '2018-07-04 11:05:04'),
(268, 33, 'on_sale', '1', '2018-07-04 11:05:04', '2018-07-04 11:05:04'),
(269, 33, 'images', 'a:7:{i:0;s:31:\"/photos/1/rezized/50198 (2).jpg\";i:1;s:31:\"/photos/1/rezized/50198 (3).jpg\";i:2;s:31:\"/photos/1/rezized/50198 (4).jpg\";i:3;s:31:\"/photos/1/rezized/50198 (5).jpg\";i:4;s:31:\"/photos/1/rezized/50198 (6).jpg\";i:5;s:31:\"/photos/1/rezized/50198 (7).jpg\";i:6;s:31:\"/photos/1/rezized/50198 (8).jpg\";}', '2018-07-04 11:05:04', '2018-07-06 13:31:01'),
(270, 34, 'options', 'a:1:{i:0;a:3:{s:4:\"name\";N;s:7:\"options\";N;s:6:\"prices\";N;}}', '2018-07-06 13:57:14', '2018-07-06 13:57:14'),
(271, 34, 'code', '6565', '2018-07-06 13:57:14', '2018-07-06 13:57:14'),
(272, 34, 'weight', '', '2018-07-06 13:57:14', '2018-07-06 13:57:14'),
(273, 34, 'size', '22.5 X 32 inches, 57 X 82 cms', '2018-07-06 13:57:14', '2018-07-06 13:57:14'),
(274, 34, 'material', '', '2018-07-06 13:57:14', '2018-07-06 13:57:14'),
(275, 34, 'price', '', '2018-07-06 13:57:14', '2018-07-06 13:57:14'),
(276, 34, 'keywords', '', '2018-07-06 13:57:14', '2018-07-06 13:57:14'),
(277, 34, 'metadesc', '', '2018-07-06 13:57:14', '2018-07-06 13:57:14'),
(278, 34, 'related_article', 'N;', '2018-07-06 13:57:14', '2018-07-06 13:57:14'),
(279, 34, 'antique_thanka', '1', '2018-07-06 13:57:14', '2018-07-06 13:57:14'),
(280, 34, 'popular_thanka', '0', '2018-07-06 13:57:14', '2018-07-06 13:57:14'),
(281, 34, 'feature_thanka', '0', '2018-07-06 13:57:14', '2018-07-06 13:57:14'),
(282, 34, 'on_sale', '1', '2018-07-06 13:57:14', '2018-07-06 13:57:14'),
(283, 34, 'images', 'a:10:{i:0;s:31:\"/photos/1/rezized/6565 (10).jpg\";i:1;s:31:\"/photos/1/rezized/6565 (11).jpg\";i:2;s:30:\"/photos/1/rezized/6565 (2).jpg\";i:3;s:30:\"/photos/1/rezized/6565 (3).jpg\";i:4;s:30:\"/photos/1/rezized/6565 (4).jpg\";i:5;s:30:\"/photos/1/rezized/6565 (5).jpg\";i:6;s:30:\"/photos/1/rezized/6565 (6).jpg\";i:7;s:30:\"/photos/1/rezized/6565 (7).jpg\";i:8;s:30:\"/photos/1/rezized/6565 (8).jpg\";i:9;s:30:\"/photos/1/rezized/6565 (9).jpg\";}', '2018-07-06 13:57:14', '2018-07-06 13:57:14'),
(284, 35, 'options', 'a:1:{i:0;a:3:{s:4:\"name\";N;s:7:\"options\";N;s:6:\"prices\";N;}}', '2018-09-06 05:53:46', '2018-09-06 05:53:46'),
(285, 35, 'code', '', '2018-09-06 05:53:46', '2018-09-06 05:53:46'),
(286, 35, 'weight', '', '2018-09-06 05:53:46', '2018-09-06 05:53:46'),
(287, 35, 'size', '', '2018-09-06 05:53:46', '2018-09-06 05:53:46'),
(288, 35, 'material', '', '2018-09-06 05:53:47', '2018-09-06 05:53:47'),
(289, 35, 'price', '', '2018-09-06 05:53:47', '2018-09-06 05:53:47'),
(290, 35, 'keywords', '', '2018-09-06 05:53:47', '2018-09-06 05:53:47'),
(291, 35, 'metadesc', '', '2018-09-06 05:53:47', '2018-09-06 05:53:47'),
(292, 35, 'related_article', 'N;', '2018-09-06 05:53:47', '2018-09-06 05:53:47'),
(293, 35, 'antique_thanka', '0', '2018-09-06 05:53:47', '2018-09-06 05:53:47'),
(294, 35, 'popular_thanka', '0', '2018-09-06 05:53:47', '2018-09-06 05:53:47'),
(295, 35, 'feature_thanka', '0', '2018-09-06 05:53:47', '2018-09-06 05:53:47'),
(296, 35, 'on_sale', '0', '2018-09-06 05:53:47', '2018-09-06 05:53:47'),
(297, 35, 'images', 'a:1:{i:0;N;}', '2018-09-06 05:53:47', '2018-09-06 05:53:47');

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `userid` int(11) DEFAULT NULL,
  `title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci,
  `content` text COLLATE utf8mb4_unicode_ci,
  `clean_url` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `menu_order` int(11) DEFAULT NULL,
  `cmt_count` int(11) DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `userid`, `title`, `name`, `excerpt`, `content`, `clean_url`, `post_type`, `image`, `menu_order`, `cmt_count`, `status`, `created_at`, `updated_at`) VALUES
(2, NULL, 'Page Testing Edit', 'Page Testing Edit', NULL, NULL, 'page-testing-edit', 'page', '/photos/1/see.jpg', NULL, NULL, '1', '2018-05-08 22:37:04', '2018-05-08 22:37:04'),
(4, NULL, 'Lorem Ipsum', 'Lorem Ipsum', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s,', '<div>\r\n<h2>What is Lorem Ipsum?</h2>\r\n<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>\r\n</div>\r\n<div>\r\n<h2>Why do we use it?</h2>\r\n<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>\r\n</div>', 'lorem-ipsum', 'page', '/photos/1/hawks-landing-bungalow-wolf-custom-homes-4092410 (1).jpeg', NULL, NULL, '1', '2018-05-15 04:29:27', '2018-05-15 04:43:00'),
(12, 1, 'Amitab buddha 12.5 x 16.5 Inches, 32 x 42 Cms', 'Amitab buddha 12.5 x 16.5 Inches, 32 x 42 Cms', 'Amitabha Buddha is red in color and he is seated in a meditative posture , hence his mudra is called \'dhyanamudra\'.', '<p>Amitabha Buddha is red in color and he is seated in a meditative posture ; hence his mudra is called &lsquo; dhyanamudra&rsquo; . His two palms are joined together with the right on the left , two thumbs of both hands touching each other . An Alms bowl is between his two palms . Here the hand gesture &nbsp;, representing meditative equipoise ,&nbsp; represents the unity of wisdom and compassion .</p>\r\n<p>Through his knowledge of discriminate wisdom , a bodhisattva understands the empty nature of all sentient beings and develops great compassion for them . This is the dhyana or meditation of Buddha Amitabha .</p>\r\n<p>His color is red , symbolizing the fires of desire . When&nbsp; a Boddhisattva understands the discriminative wisdom of Amitabha Buddha he can use even the fires of desire on the path to Enlightenment . His symbol is lotus , representing purity . Though he himself is untainted by the evils of samsara , he nevertheless takes birth in samsara for the benefit of the sentient beings .</p>', 'amitab-buddha-125-x-165-inches-32-x-42-cms', 'product', NULL, NULL, NULL, '1', '2018-05-17 23:23:07', '2018-05-17 23:23:07'),
(13, 1, 'Product with related articles', 'Product with related articles', NULL, NULL, 'product-with-related-articles', 'product', NULL, NULL, NULL, '1', '2018-05-22 22:57:08', '2018-05-22 22:57:08'),
(18, 1, 'Our Gallery', 'Our Gallery', NULL, NULL, 'our-gallery', 'banner', '/photos/1/banner/thangka-showroom.jpg', NULL, NULL, '1', '2018-06-11 03:00:30', '2018-07-15 14:48:24'),
(19, 1, 'Handle Sample 1', 'Handle Sample 1', NULL, NULL, 'handle-sample-1', 'handle', '/photos/1/handle/handle-sample-1.png', NULL, NULL, '1', '2018-06-13 23:34:52', '2018-07-09 16:44:54'),
(20, 1, 'Brocade Sample 1', 'Brocade Sample 1', NULL, NULL, 'brocade-sample-1', 'brocade', '/photos/1/brocade/brocade-sample-1.png', NULL, NULL, '1', '2018-06-13 23:35:26', '2018-07-09 16:41:42'),
(21, 1, 'Kalachakra Mandala', 'Kalachakra Mandala', 'Kalachakra mandala is the “Palace of Purity”with more than seven hundred deities residing inside ,represented by various signs and symbols .The entrances of the palace  nearest to the centre are  said to be cittacakra(mind-wheels),and the middle entrances are said to be vakcakra(voice-wheels).Outside the gates of vakcakra are figures of various animals,including a corpse,and marigold-like lotus flower.They include a deer,buffalo,ram peacock,elephant,mongoose ,bull,makara,mouse,and the Garuda.They are the vehicles of various divinities of the Hindu pantheon.', '<p>It is reported that in the year after Buddha Shakyamuni attained Enlightenment,he was asked by King Chandrabhadra of Shambhala to teach the Kalachakra Tantra.The Buddha manifested himself in the form of the Kalachakra meditational deity and gave the full teachings and initiation of this tantra.The kalachakra teaching was then transmitted through a lineage of seven kings and 25&nbsp; propagators.</p>\r\n<p>Kalachakra mandala is the &ldquo;Palace of Purity&rdquo;with more than seven hundred deities residing inside ,represented by various signs and symbols .The entrances of the palace&nbsp; nearest to the centre are&nbsp; said to be cittacakra(mind-wheels),and the middle entrances are said to be vakcakra(voice-wheels).Outside the gates of vakcakra are figures of various animals,including a corpse,and marigold-like lotus flower.They include a deer,buffalo,ram peacock,elephant,mongoose ,bull,makara,mouse,and the Garuda.They are the vehicles of various divinities of the Hindu pantheon.</p>\r\n<p>The outermost gates belong to the third circle called kayacakra(body-wheels).There are four gates and four chariots one in each gate.You can see boars drawing a chariot at the eastern gate,horses drawing the chariot at the southern gate,elephants at the western gate and lions drawing the chariot at the northern gate.</p>\r\n<p>Kalachakra Mandala is one of the most complicated forms of Tibetan mandalas which is used as a device for meditation and which is worshipped for the betterment of all the sentient beings.It also represents the cosmos system which consists of the five major elements of life. Namely &ndash; Fire , Earth , Water , Air and Space .</p>', 'kalachakra-mandala', 'product', '/photos/1/products/mandala-2.jpg', NULL, NULL, '1', '2018-06-25 09:37:32', '2018-06-27 17:04:32'),
(22, 1, 'Manjushree', 'Manjushree', '“God of Divine Wisdom “ ,whose worship confers mastery of the dharma,retentive memory,mental perfection and eloquence. In Mahayana  Buddhist Tradition he is regarded as having supreme wisdom among bodhisattvas . He is also called prince of the Dharma because of his eloquent wisdom .', '<p>&nbsp;&ldquo;God of Divine Wisdom &ldquo; ,whose worship confers mastery of the dharma,retentive memory,mental perfection and eloquence. In Mahayana&nbsp; Buddhist Tradition he is regarded as having supreme wisdom among bodhisattvas . He is also called prince of the Dharma because of his eloquent wisdom .</p>\r\n<p>Manjushree has the ability to see the nature of reality as it is. In Nepal,he is considered as the founder of Nepalese civilization and the creator of Kathmandu Valley. It is said that he cut the gorge of Chobhar hill with his flaming sword &ldquo; Chandrahasa&rdquo; and let the waters flow out and thereby opened the valley for the human habitant to allow for the propagation of the Buddha Dharma.</p>\r\n<p>He carries the sword of wisdom in his right hand and Prajna Paramita Manuscript on his left on top of the lotus blossom . It is believed that worshipping Manjushree can confer upon the worshippers wisdom , memory , intelligence etc .</p>\r\n<p>&nbsp;</p>', 'manjushree', 'product', '/photos/1/14200 (1).JPG', NULL, NULL, '1', '2018-06-25 09:51:17', '2018-06-25 09:51:17'),
(23, 1, 'Mandala with Orange Background', 'Mandala with Orange Background', NULL, NULL, 'mandala-with-orange-background', 'product', '/photos/1/products/Mandala 1-min.JPG', NULL, NULL, '1', '2018-06-29 12:55:23', '2018-06-29 12:55:23'),
(24, 1, 'Mandala with Green Background', 'Mandala with Green Background', NULL, NULL, 'mandala-with-green-background', 'product', '/photos/1/products/Mandala 2-min.JPG', NULL, NULL, '1', '2018-06-29 12:56:52', '2018-06-29 12:56:52'),
(25, 1, 'High Quality Medicine Buddha', 'High Quality Medicine Buddha', NULL, NULL, 'high-quality-medicine-buddha-', 'product', '/photos/1/products/Buddha-and-Boddhisattvas-min.jpg', NULL, NULL, '1', '2018-06-29 13:05:36', '2018-07-04 10:34:32'),
(26, 1, 'Mandala with Bluish Background', 'Mandala with Bluish Background', NULL, NULL, 'mandala-with-bluish-background', 'product', '/photos/1/products/Mandala 4-min.JPG', NULL, NULL, '1', '2018-06-29 13:07:24', '2018-06-29 13:07:24'),
(27, 1, 'Mandala with Yellow Background', 'Mandala with Yellow Background', NULL, NULL, 'mandala-with-yellow-background', 'product', '/photos/1/products/Mandala 5-min.JPG', NULL, NULL, '1', '2018-06-29 13:12:20', '2018-06-29 13:12:20'),
(28, 1, 'Mandala with Yellow Circle', 'Mandala with Yellow Circle', NULL, NULL, 'mandala-with-yellow-circle', 'product', '/photos/1/products/Mandala 6-min.JPG', NULL, NULL, '1', '2018-06-29 13:17:37', '2018-06-29 13:17:37'),
(29, 1, 'Mandala with Red Background', 'Mandala with Red Background', NULL, NULL, 'mandala-with-red-background', 'product', '/photos/1/products/Mandala 10-min.JPG', NULL, NULL, '1', '2018-06-29 13:33:55', '2018-06-29 13:33:55'),
(30, 1, 'Mandala with Red Circle', 'Mandala with Red Circle', NULL, NULL, 'mandala-with-red-circle', 'product', '/photos/1/products/Mandala 7-min.JPG', NULL, NULL, '1', '2018-06-29 13:36:43', '2018-06-29 13:36:43'),
(31, 1, 'Mandala with Brown Circle', 'Mandala with Brown Circle', NULL, NULL, 'mandala-with-brown-circle', 'product', '/photos/1/products/Mandala 8-min.JPG', NULL, NULL, '1', '2018-06-29 13:38:23', '2018-06-29 13:38:23'),
(32, 1, 'Mandala with Black Circle', 'Mandala with Black Circle', NULL, NULL, 'mandala-with-black-circle', 'product', '/photos/1/products/mandala-2.jpg', NULL, NULL, '1', '2018-06-29 13:40:04', '2018-06-29 13:40:04'),
(33, 1, '21 Tara', '21 Tara', NULL, NULL, '21-tara', 'product', '/photos/1/rezized/50198 (1).jpg', NULL, NULL, '1', '2018-07-04 11:05:04', '2018-07-06 13:31:01'),
(34, 1, 'Wheel Of Life', 'Wheel Of Life', NULL, '<p>According to&nbsp; the&nbsp; ancient texts the original model for the Wheel of life was painted over the gateway of the Veluvana Bihara at Rajagriha on the instructions of the Buddha himself, who indicated exactly how the work should be done. The &nbsp;Buddha, was inspired by the activities of one of his chief disciples, Maudgalyayana . Thanks to his mastery of psychic powers, Maudgalyayana was able to visit all beings in the different realms of existence, and to see&nbsp; them in different states of pain or pleasure; as a result, he became aware of the causes of these different states .The Buddha realized that there were not enough people like Maudgalyayana to teach all those who needed to hear his teaching .He therefore&nbsp; instructed his disciples to paint the Wheel of Life ,a depiction of the different realms of existence , and their underlying processes ,at the entrance to every monastery .The picture is not strictly a literal account of worldly existence ,but is effective in that&nbsp; it appeals to our imagination with its rich and powerful imagery.</p>\r\n<p>&nbsp;</p>\r\n<p>&nbsp;</p>\r\n<p>The wheel of existence is considered an endless life circle of human being. In the painting we can see a pig, a snake and a cock in the centre circle symbolizing ignorance, anger and greed respectively .These are the three cardinal sins of life which cause aversions and hindrances. The second circle shows good people moving upwards to heaven and the sinners being dragged down to hell. The third circle shows the six world of existence and the fourth and last circle shows the chain of cause and effect.The wheel of life is held by the lord of death or Yama which symbolizes that death is inevitable and good deeds or good karma lead to a better after life.</p>', 'wheel-of-life', 'product', '/photos/1/rezized/6565 (1).jpg', NULL, NULL, '1', '2018-07-06 13:57:14', '2018-07-06 13:57:14'),
(35, 1, 'New product with stock', 'New product with stock', NULL, '<p><strong>Lorem Ipsum</strong>&nbsp;is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>', 'new-product-with-stock', 'product', NULL, NULL, NULL, '1', '2018-09-06 05:53:46', '2018-09-06 05:55:08');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `all` tinyint(1) NOT NULL DEFAULT '0',
  `sort` smallint(5) UNSIGNED NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `all`, `sort`, `created_at`, `updated_at`) VALUES
(1, 'Administrator', 1, 1, '2018-04-30 01:45:20', '2018-04-30 01:45:20'),
(2, 'Executive', 0, 2, '2018-04-30 01:45:20', '2018-04-30 01:45:20'),
(3, 'User', 0, 3, '2018-04-30 01:45:20', '2018-04-30 01:45:20');

-- --------------------------------------------------------

--
-- Table structure for table `role_user`
--

CREATE TABLE `role_user` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `role_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_user`
--

INSERT INTO `role_user` (`id`, `user_id`, `role_id`) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 3, 3),
(6, 5, 3),
(7, 6, 3),
(8, 7, 3),
(9, 8, 3);

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('l0551O4VHcw50D78DGOSZ4irKeUUYVNMszg9Lxaj', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36', 'ZXlKcGRpSTZJbGhMU0VsUE9XSnNYQzltUlZ3dmRUVlZUMFE0Wlhsdlp6MDlJaXdpZG1Gc2RXVWlPaUozYm01VFUycExVbU0yVTNJeloyVldNSGRaWlc1Q1pYUXpVVmxIY3psVGFWUkxPVlpoV2t3MFMxVXJNa0pSY2xZMU5VZE5RbGxQWlRWNVZFaENZWG96U1VkU2FYVnVaazVNZFdsM1ZVNHJlSFJrUjNONVZuRkxObU4xSzNCVVJ6YzVZVmhMWTBGaFRHSjFVa3RCU2taUVdIVXlZMlp5TWxwNlFYWmtWMjFMV0Z3dmEyZEdSRk55Tm1OeWEyZEllVk5hU0hwUFRGSmFXakJUU21aRmJFbFZZbmRaZGtOSmFWWjRjMDVuZWx3dlYxRnJYQzlGT0RKbVlrSmxka1E0WVVFelpsQnlSMXd2UmtwWU5DdHFRall5Y0VKT1JIbE1SRkUwVTFScGNteExlRzV3TWpKWVRGTlBWV3hqYjFwSFltWmxkU3RFTm05eWRXeE5SREpvVDJNd1ZtZDBha0ZqZVVKblZUWjZaSFp4U0V0dWNWd3ZVbmRFTkZKS1NtWXJkSGhIVDNnMk1taGhOSE5uVGpScmN6RXJOVkZzWVROb1JXTnNkR2d6VEdsbFhDODBURE5oWW1Sa1IwbGhRbWQyYWs5dFZXSnpPRGxOZGs0eWFXSlhRMDl2VkVOTVQzQlRjSFZ1UmxoT1lqSkZUMFpVWkhGNk5VMDRWVVZaVGt0cGJFbE5LM3BRUlRabFdIbzRZVTlyZFVSVlVWZDVlbVowUjFGek9VbEViSFpyUmx3dmJYSmFSbTQ1U0dWNFRqZDJNRThyYlVzck4xWmxUSGhqYTFJM1FXWjJUblJFZVdGaFZqaHhkRlZDWVc5eVppdDRYQzl4ZUdaUGVHZExVRUZxV21FMmIwNDRRbmhzV1ZKR09YZG5NbXA2VFVrNFBTSXNJbTFoWXlJNkltSTJZamN4TlRZM1ptTTBOMkl5WXpJd01qazFZbUppTVRka1lqUTBZMkl4TjJRNE1tVTNNelJoWlRZd016WTNPRFkwTTJRd05qTXdaVGM1WTJVNFpERWlmUT09', 1530526245),
('Nb2J9VnARYDYdyi1C30rWfghy2lAAqurEFa8sonq', 5, '127.0.0.1', 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.99 Safari/537.36', 'ZXlKcGRpSTZJbTFtWVdoMWFYVlhZVFJoWVhOSloyeDBTbnBXV1hjOVBTSXNJblpoYkhWbElqb2liVzVvUVdwTk9VSnVTalpVVjJSTmEyNVhNMDVzYW5WYWFtSTNORWx2TjJsalNtYzRUVEpIVlRWUWNXZDJSakptUzNSbFFWUXJVM0JuVkZ3dmFFcEtUVzF5VVdoclprZDNTM281ZUVsQmRtZDNkRkJGU1ZCdFJ6QnNZblp1V0VwdWNWbFVPWGcyTmxKcVVXeEtWMGxJWW5sQmNUZFVUSFpyV0c5S2Jsa3hVemRvWWxSbVUxWk1VRGRRTmxjMVdWZGtSVlV3UkVwdWJESjJiRTFMVERSYWJFNTBaamhqY2xGdUsxcEtPWEZZSzFCa1VIUmFVMXBYTWtSRU5FUkpZMXBjTDNGRlpXZFRkVGRRU2tscVRGWnVWRzFPZEVJeVZtSnBlVzVxU0dWR1NXTjBkM0YxZGtJMU9XbHJaWFI1VG5WS1ZYQXdTekF5TVhrNVZrOU1RbGRtY0c1WWVXNUJWbWhwYWpWeFFWd3ZVMXd2VFVoNk9USnliblJSTjFsTGFWSXdOeXRQWlhkT1RqRlFTemhLYkRSMWRqRndNRE52TUZ3dlJuUkZTV3hZYnpCQlpsTkVabmRrU0cxNlpWcDFYQzlrVmtzMFZUTk1jMVZtZEVOaVYxRTFSVVZVZFdWcWMzQjBjVlJ6WmxrcmEycGphaXRLVW14SWFrY3lVR2gyVlRReVdtNDJOM3BCYlRKTVZIbFdlRUZGYVNzeGJsRXhUSGd3VjBaV1EwdzVlbXhOU0ZSeVdYaEJRVFpJTWxwVFMyNDJORDBpTENKdFlXTWlPaUkzTXpJNU9UbGxOR1ptTldNNE5XRXhNV1ZrWXpOaE5XSTJaakppWkRVMk5XRTVObUV6WlRNNU56YzVZalUzTnprM09XVmlOR1ZsTnpZMU5XSTRZV1UwSW4wPQ==', 1530591141);

-- --------------------------------------------------------

--
-- Table structure for table `social_logins`
--

CREATE TABLE `social_logins` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `provider` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `provider_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `stocks`
--

CREATE TABLE `stocks` (
  `id` int(10) UNSIGNED NOT NULL,
  `postid` int(11) NOT NULL,
  `org_stock` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `in_stock` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sold_stock` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cost_price` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selling_price` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bought_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `stocks`
--

INSERT INTO `stocks` (`id`, `postid`, `org_stock`, `in_stock`, `sold_stock`, `cost_price`, `selling_price`, `bought_date`, `created_at`, `updated_at`) VALUES
(1, 21, '10', '7', '3', '500', '512', '2018-07-01', '2018-07-02 01:32:44', '2018-08-01 04:51:52'),
(2, 21, '5', '5', '0', '480', '500', '2018-07-03', '2018-07-02 01:38:10', '2018-07-02 01:38:10'),
(3, 12, '20', '20', '0', '5000', '5500', '2018-07-01', '2018-07-02 23:49:08', '2018-07-02 23:49:08'),
(4, 31, '10', '8', '2', '1000', '1000', '2018-07-26', '2018-07-26 02:47:51', '2018-08-01 04:51:53'),
(5, 29, '10', '5', '5', '25000', '25000', '2018-07-26', '2018-07-26 02:48:54', '2018-08-01 04:56:23'),
(6, 35, '10', '10', '0', '1500', '2000', '2018-09-18', '2018-09-06 05:53:46', '2018-09-06 05:53:46');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(3) UNSIGNED NOT NULL DEFAULT '1',
  `confirmation_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confirmed` tinyint(1) NOT NULL DEFAULT '0',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `status`, `confirmation_code`, `confirmed`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Admin', 'Istrator', 'admin@admin.com', '$2y$10$YBpMooBwZ1aszuNUpfWIHurgyMEXeZi/zlbRJdCwuW3umeh5Age.C', 1, '066ab591c68d9b930dc9e0410e8eca12', 1, 'Hd594VR8etFKiDzRmVeA5rIdGFsdFrxEudoqEpame7pBAjCRPa7uyExXsk9y', '2018-04-30 01:45:19', '2018-04-30 01:45:19', NULL),
(2, 'Backend', 'User', 'executive@executive.com', '$2y$10$AVIF7MGqpPf9r2RK7ycD3.aILHQ6Fg0ege71Ft6TNlCAhdlBUae0q', 1, '4e15e56561caafdeed8f61c7ab52630b', 1, NULL, '2018-04-30 01:45:19', '2018-04-30 01:45:19', NULL),
(3, 'Default', 'User', 'user@user.com', '$2y$10$FedHvibVAYyYPdVSLVzgcOlTOgQb1CZypmO9FWUVlZdVbJZunYife', 1, 'ad8a7827e6450f6c4965afc6884fc51c', 1, 'Z56aQw0PTd6VE0lFBaxn1ANCbOVLVPrQy6RqYVSoFFrumS0bxXEEOlgZdvPh', '2018-04-30 01:45:19', '2018-04-30 01:45:19', NULL),
(5, 'binaya', 'shrestha', 'binaya619@gmail.com', '$2y$10$L1rR4qfjCnZ9ObCOpOstF./N0V8QPx.fOZ4skTIpN/ExAC6Yyr8lO', 1, '43e3b5ad8a6b0b307afae45245086446', 1, '7K9tHUZ9BpE2WJwAU4R79SCvCTrm9l1YGUtL8r1DBJkll1f0tW9hIDfe4W6B', '2018-05-28 00:36:03', '2018-05-28 01:19:33', NULL),
(6, 'Ayaz', 'Udin', 'ayaz.din@gmail.com', '$2y$10$pzAbVVrBZMKxkV65Q0z/LuejEFUSRnAQaCCMsHGqDin65i3hIeIcO', 1, '9738d72882885f87a4804a8c777c27ec', 1, NULL, '2018-05-28 22:24:41', '2018-05-28 22:27:56', NULL),
(7, 'Sanjeev', 'Singh', 'masanjeev@gmail.com', '$2y$10$8Hin1b0vSqJPQKBx.1HwvuDC40dCQaemDqGhk9N3KpAUAUTMLYzQa', 1, 'a2ee861a4019f1e2b08d325068c5856c', 1, NULL, '2018-05-28 22:25:52', '2018-05-28 22:43:25', NULL),
(8, 'nameen', 'Dangol', 'nameen17@gmail.com', '$2y$10$Vmi6vY5t8qdRBTIC9LKb5Obn1P7kGrTwpKmACH7XlfQrfmOc6yvIG', 1, 'e6538e319417d8ecd683a93546db962e', 0, NULL, '2018-08-16 23:58:40', '2018-08-16 23:58:40', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `artists`
--
ALTER TABLE `artists`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `buyers_allocations`
--
ALTER TABLE `buyers_allocations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cat_relations`
--
ALTER TABLE `cat_relations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `exchange_rates`
--
ALTER TABLE `exchange_rates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `history`
--
ALTER TABLE `history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `history_type_id_foreign` (`type_id`),
  ADD KEY `history_user_id_foreign` (`user_id`);

--
-- Indexes for table `history_types`
--
ALTER TABLE `history_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_unique` (`name`);

--
-- Indexes for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD PRIMARY KEY (`id`),
  ADD KEY `permission_role_permission_id_foreign` (`permission_id`),
  ADD KEY `permission_role_role_id_foreign` (`role_id`);

--
-- Indexes for table `postcats`
--
ALTER TABLE `postcats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `postmetas`
--
ALTER TABLE `postmetas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_unique` (`name`);

--
-- Indexes for table `role_user`
--
ALTER TABLE `role_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_user_user_id_foreign` (`user_id`),
  ADD KEY `role_user_role_id_foreign` (`role_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD UNIQUE KEY `sessions_id_unique` (`id`);

--
-- Indexes for table `social_logins`
--
ALTER TABLE `social_logins`
  ADD PRIMARY KEY (`id`),
  ADD KEY `social_logins_user_id_foreign` (`user_id`);

--
-- Indexes for table `stocks`
--
ALTER TABLE `stocks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `artists`
--
ALTER TABLE `artists`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `buyers_allocations`
--
ALTER TABLE `buyers_allocations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cat_relations`
--
ALTER TABLE `cat_relations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `exchange_rates`
--
ALTER TABLE `exchange_rates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=246;

--
-- AUTO_INCREMENT for table `history`
--
ALTER TABLE `history`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `history_types`
--
ALTER TABLE `history_types`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `permission_role`
--
ALTER TABLE `permission_role`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `postcats`
--
ALTER TABLE `postcats`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `postmetas`
--
ALTER TABLE `postmetas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=298;

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `role_user`
--
ALTER TABLE `role_user`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `social_logins`
--
ALTER TABLE `social_logins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `stocks`
--
ALTER TABLE `stocks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `history`
--
ALTER TABLE `history`
  ADD CONSTRAINT `history_type_id_foreign` FOREIGN KEY (`type_id`) REFERENCES `history_types` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `history_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `permission_role`
--
ALTER TABLE `permission_role`
  ADD CONSTRAINT `permission_role_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `permission_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_user`
--
ALTER TABLE `role_user`
  ADD CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `social_logins`
--
ALTER TABLE `social_logins`
  ADD CONSTRAINT `social_logins_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
